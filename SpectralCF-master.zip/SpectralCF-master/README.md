# SpectralCF
#### Requirements:
##### Python 3.5
##### TensorFlow 1.4.0-rc0
##### NumPy 1.14.0
